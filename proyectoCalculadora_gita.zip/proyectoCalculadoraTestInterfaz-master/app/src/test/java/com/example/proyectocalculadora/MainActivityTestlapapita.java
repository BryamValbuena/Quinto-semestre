package com.example.proyectocalculadora;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

public class MainActivityTestlapapita {
    @Test
    public void testresta() {
        Calculadora calculadora = new Calculadora();
        double resultado = calculadora.restar(8.0, 4.0);
        assertEquals(4.0, resultado, 0.001);
    }

}